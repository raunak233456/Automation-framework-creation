package Day2;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

public class pojogettersettercall {
	@Test
	void testPOJO()
	{
	POJOClass p = new POJOClass();
	p.setName("RAunak");
	String courses[] = {"J","P"};

	p.setCourses(courses);

	p.setLocation("India");
	p.setPhone("1881");
	given()
	//type of data sending
	.contentType("application/json")
	.body(p)//can not send data directly, need to convert to string

	.when()
	      .post("http://localhost:3000/students")
	      

	.then()
	.statusCode(201)
	.body("name",equalTo("RAunak"))
	.body("location",equalTo("India"))
	.body("courses[1]",equalTo("P"))
	.log().all();

	}

}
