package Day2;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;
import org.testng.annotations.Test;


public class DiffWaysToCreatePost 
{
	int id;
	//using hashmap
	
	@Test(priority = 0)
	public void Posthashmap()
	
	{
		HashMap data = new HashMap();
		data.put("name", "Scott");
		data.put("location","India");
		data.put("phone","1616171");
		
		
		String courseARR[] = {"C", "C++"};
		data.put("courses",courseARR);
		
		given()
		//type of data sending
		.contentType("application/json")
		.body(data)
		
		.when()
		      .post("http://localhost:3000/students")
		      
		
		.then()
		.statusCode(201)
		.body("name",equalTo("Scott"))
		.body("location",equalTo("India"))
		.body("courses[0]",equalTo("C"))
		.log().all();
		
	}
	
	@Test(priority =1)
	public void delete()
	{
		given()
		
		.when()
		
		.delete("http://localhost:3000/students/4")
		
		.then()
		.statusCode(204);
	

}

}
	 