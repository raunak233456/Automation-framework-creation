package Day3;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;



public class QueryParam {

	
	@Test
	void TestQuerYPath()
	{
	given()
	  .pathParam("path","users")
	  .queryParam("page","2")
	
	.when()
	 .get("https://reqres.in/api/{path}")
	
	.then()
	.statusCode(200)
	.log().all();
	
	
	}
}
