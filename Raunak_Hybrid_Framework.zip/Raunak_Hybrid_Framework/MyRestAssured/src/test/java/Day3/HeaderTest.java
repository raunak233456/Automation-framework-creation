package Day3;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;



import org.testng.annotations.Test;

import com.github.scribejava.core.model.Response;

import io.netty.handler.codec.Headers;
import io.restassured.http.Header;

public class HeaderTest {
	
	@Test
	void header()
	{
		given()
		.when()
		.get("https://www.google.com/")
		
		.then()
		.statusCode(200)
		.header("Content-Type", "text/html; charset=ISO-8859-1")
		.and()
		.header("Content-Encoding", "gzip");
		
		
	}
	
		@Test(priority =2)
		void headerinfo()
		{
	/*	Response res =  given()
			
			.when()
			
			.get("https://www.google.com/");
	
		
	Headers hed = (Headers) res.getHeaders();
		for(Header hd :hed)
		{
			System.out.println(hd.getName()+ "   "+hd.getValue());
		}*/
		
		}		
			
			
		}
	


