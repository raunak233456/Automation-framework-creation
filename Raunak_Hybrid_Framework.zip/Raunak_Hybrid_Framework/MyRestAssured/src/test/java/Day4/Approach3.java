package Day4;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class Approach3 {

	//when order of students will change how to get students[3].name
	
//use jsonObjects to traverse through all elements
	@Test
	void test()
	{
	Response res = 
			given()
			.contentType("Content-Type.JSON")
			
			.when()
			.get("http://localhost:3000/students");
	
	
	JSONObject OB = new JSONObject(res.asString());//convert sting response to jsonobject
	
 for(int i =0;i<OB.getJSONArray("students").length();i++)
 {
	 String name = OB.getJSONArray("students").getJSONObject(i).get("name").toString();
	 System.out.println(name);
 }

	

	}
	
			
	
}
