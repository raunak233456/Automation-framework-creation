package Day4;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.github.scribejava.core.model.Response;

import io.restassured.response.ResponseBodyExtractionOptions;



public class Approach2 {

	
	 @Test
	void getjsondata()
	{
		io.restassured.response.Response res = given()
				.contentType("ContentType.JSON")
				
				.when()
				.get("http://localhost:3000/students");
		
		
				Assert.assertEquals(res.getStatusCode(),200);
				Assert.assertEquals(res.header("Content-Type"),"application/json; charset=utf-8");
				
				
				String name = ((ResponseBodyExtractionOptions) res).jsonPath().get("students[2].name").toString();
				Assert.assertEquals(name,"Kim");
				
				
	}
}
