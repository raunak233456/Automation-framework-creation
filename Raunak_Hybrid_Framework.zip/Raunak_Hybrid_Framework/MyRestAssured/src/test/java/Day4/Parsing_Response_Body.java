package Day4;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class Parsing_Response_Body {
 // validation on then
	
	@Test
	void testJsonResponse()
	{
		given()
		.contentType("contenttype.JSON")
	
		.when()
		
		.get("http://localhost:3000/students")
		
		.then()
		
		.statusCode(200)
		.header("Content-Type","application/json; charset=utf-8");
		//.body("students.name",equalTo("Kim"));
		
		
	}
}
