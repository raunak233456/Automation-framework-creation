package Day1;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;

import org.testng.annotations.Test;


public class htttpRequest {
	private static final String PostCreateuser = null;
	int id;
	//when(), when(), then()
	
	@Test(priority =1)
	void getusers()
	{
		given()
		
		.when()
		 .get("https://reqres.in/api/users?page=2")// we can remove given if nothing inside but but then remove dot from when
		        
		  
		.then()
		
        .statusCode(200)//validate status code
        .body("page",equalTo(2))//validate body page number

		.log().all();// last step so specify semicolon, this will represent entire response
		
	}
	
	@Test(priority =2)
	void PostCreateuser()//data we are sending , what type of data, use hashmap
	
	{
		
		HashMap hm = new HashMap();
		
		hm.put("name", "RK");
		hm.put("job", "tester");
		
		id=given()//content type
		//.contentType("application/json")//json data
		//capture id
		.contentType("application/json")
		.body(hm)
		
		.when()
		
		.post("https://reqres.in/api/users")

		.jsonPath().getInt("id"); //Capture id
		
		
		
		
		//.then()
		//.statusCode(201)
		//.log().all();
		
	}
	@Test(priority =3, dependsOnMethods={"PostCreateuser"})//if create user is failed then don't want to execute update testcase-dependence on method
	void putupdate()
	{
		 
			
			HashMap hm = new HashMap();
			
			hm.put("name", "RK");
			hm.put("job", "SDET");
			
			given()//content type
			//.contentType("application/json")//json data
			//capture id
			.contentType("application/json")
			.body(hm)
			
			.when()
			
			    .put("https://reqres.in/api/users"+id)
			
			
		.then()
		  .statusCode(200)
			.log().all();
		
		}
		
	}
	
	 
		
	
