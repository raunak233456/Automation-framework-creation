package com.amazon.testCases;



import org.testng.Assert;
import org.testng.annotations.Test;

import com.amazon.pageObject.LoginPage;

public class TC_LoginTest_01 extends BaseClass{
	
	@Test
	public void loginTest()
	{
     driver.get(baseURL); 
     
     logger.info("URL is open");
     
         
             LoginPage lp = new LoginPage(driver); // use page object class, class method by creating objects 
             
             lp.AccountSignin();
             logger.info("Continue to sign in ");
             
             lp.setusername(username);
             logger.info("Entered username");
             lp.Continuetopassword();
             logger.info("Continue to password enter page");
             lp.setpass(password);
             logger.info("Entered password");
             lp.Submitbtn();
             logger.info("Submit button clicked");
             
             
              /*  if(driver.getTitle().equals("Amazon.com. Spend less. Smile more."))  // get title of page 
                {
                	Assert.assertTrue(true);
                }
                else
                {
                	Assert.assertTrue(false);
                }*/
}
}