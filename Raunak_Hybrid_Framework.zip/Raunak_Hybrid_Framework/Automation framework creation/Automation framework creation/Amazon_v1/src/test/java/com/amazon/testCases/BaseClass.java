package com.amazon.testCases;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.amazon.utilities.Readconfig;

public class BaseClass {
	
	Readconfig readconfig = new Readconfig(); // create objects of class

	public String baseURL=  readconfig.getApplicationURL(); // call method
	public String username = readconfig.getusername();
	public String password = readconfig.getpassword();
	
	public static WebDriver driver;
	 public static Logger logger;
	
	@BeforeClass // Before executing tc class setup method will executed
	public void setup()
	{
		//System.setProperty("webDriver.chrome.driver",System.getProperty("user.dir")+"\\Drivers\\chromedriver.exe");
		System.setProperty("webdriver.http.factory", "jdk-http-client");	
		System.setProperty("webdriver.chrome.driver",readconfig.getChromepath());
		 
				//complete path is too long , System.getProperty(user.dir) will give  project home directory 
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		logger = Logger.getLogger("amazon"); //create logger class
		PropertyConfigurator.configure("Log4j.properties");
		
	}
	
	
	@AfterClass // after completion of testcase
	public void TearDown()
	{
		driver.quit();
		
	}
}
