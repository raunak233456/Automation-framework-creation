package com.amazon.pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	WebDriver ldriver; //create driver object
	
	public LoginPage(WebDriver rdriver)// constructor, it will take driver as parameter
	{
		ldriver= rdriver;
		PageFactory.initElements(rdriver, this);
		
		// The initElements method is used to initialize web elements. 
	}
	
	@FindBy(xpath="//span[@class='nav-line-2 ']")       //@FindBy: An annotation used in Page Factory to locate and declare web elements using different locators.
	@CacheLookup                     // @CacheLookup is used to mark the WebElements once located so that the same instance in the DOM can always be used
    WebElement Accountsignin;
	
	
	@FindBy(name="email")
	@CacheLookup
	WebElement txtusername;
	
	
	@FindBy(id="continue")
	@CacheLookup
	WebElement Continuebtn;
	
	
	@FindBy(name="password")
	@CacheLookup
	WebElement txtpassword;
	
	
	@FindBy(id="signInSubmit")
	@CacheLookup
	WebElement signInbtn;
	
	
	public void AccountSignin()//write action method
	{
		Accountsignin.click();
		
	}
  	
	public void setusername(String uname)//write action method
	{
		txtusername.sendKeys(uname);
		
	}
	public void Continuetopassword()//write action method
	{
		Continuebtn.click();
		
	}
	public void setpass(String pass)//write action method
	{
		txtpassword.sendKeys(pass);
		
	}
	public void Submitbtn()//write action method
	{
		signInbtn.click();
		
	}
}
