package com.amazon.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class Readconfig {
	
	Properties pro ;// create object for properties
	
	public Readconfig() { //create constructor , load config prop file
		
		
		File src = new File("./Configurations/config.properties");
		
		try
		{
			FileInputStream fis = new FileInputStream(src);
			 pro =  new Properties();
			 
			 pro.load(fis);
			 
		}
		catch(Exception e)
		{
			System.out.println("Exception  is "+ e.getMessage());
			
		}
	}
	
	 public String getApplicationURL()  // To read value from file, create differnt  method
	 {
		 String url = pro.getProperty("baseURL");
		 return url;
	 }
	 
	 public String getusername()  // To read value from file, create differnt  method
	 {
		 String username  = pro.getProperty("username");
		 return username;
		 
	 }
	 
	 
	 public String getpassword()  // To read value from file, create differnt  method
	 {
		 String pass  = pro.getProperty("Password");
		 return pass;
		 
	 }
	 
	 
	 public String getChromepath()  // To read value from file, create differnt  method
	 {
		 String chromepath  = pro.getProperty("chromepath");
		 return chromepath;
		 
	 }
	 
	 
	 public String getIEpath()  // To read value from file, create differnt  method
	 {
		 String IEpath  = pro.getProperty("IEpath");
		 return IEpath;
		 
	 }
	 
	 public String getEdgepath()  // To read value from file, create differnt  method
	 {
		 String Idgepath  = pro.getProperty("Edgepath");
		 return Idgepath ;
		 
	 }
}

