package Amazon_version1.Amazon_version1;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfiguration {

}
