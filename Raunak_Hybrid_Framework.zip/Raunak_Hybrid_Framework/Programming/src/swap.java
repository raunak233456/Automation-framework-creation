
public class swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int a = 10;
  int b = 20;
  
  System.out.println("Before swapping:" +a+ " " +b);
  
  /*int c = a;
  a=b;
  b=c;
  System.out.println("After SWapping:"+a+ " " +b);*/
  
	
  //Logic 2 - without usimg 3rd variable
  
  a= a+b;
  b=a-b;
  a=a-b;
  System.out.println("After SWapping:"+a+ " " +b);
  
  //Multiplication operator and division when a and b are not zero
  
   a=a*b;
   b= a/b;
   a=a/b;
   System.out.println("After SWapping:"+a+ " " +b);

   
  
  //Logic 4- XOR operator
   
   a=a^b;
   b=a^b;
   a=a^b;
   System.out.println("After SWapping:"+a+ " " +b);
   
  
   //Login 5 - single statment
   
   b = (a+b)-(a=b);
   System.out.println("After SWapping:"+a+ " " +b);
   
	}

}
