package recursion;

public class sumdig {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(sum(101));
	}
	
	static int sum(int n)
	{
		if(n%10 == n)
			return n;
		
	
		return sum(n/10)* (n%10);
	}

}
