package recursion;

public class fibonacci {
	
	public static void main(String[] args)
	{
		System.out.println(fibo(40));
	}
	
	static int fibo(int n)
	{
		if(n<2)
			return n;
		
		
		return fibo(n-2)+fibo(n-1);
		
		 
	}

}
