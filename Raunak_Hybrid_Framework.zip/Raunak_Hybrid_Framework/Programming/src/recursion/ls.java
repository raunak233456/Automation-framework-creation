package recursion;

public class ls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {1,2,3,4,5};
		
System.out.println(search(a,5,0));
	}
	
	static int search(int[] a, int el, int index)
	{
		if(index >a.length-1)
			return -1;
		
		if (a[index] == el)
			return index;
		return search(a,el,index+1);
	}

}
