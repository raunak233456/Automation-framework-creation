package recursion;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		oneton(1);
		//ntoone(5);
		

	}
	
	static void oneton (int n)
	{
		if(n>5)
			return;
	
		System.out.print(n);
		oneton(n+1);
		System.out.print(n);
		
	}

	static void ntoone(int m)
	{
		if(m==0)
			return;

		System.out.print(m);
		
		ntoone(m-1);
		System.out.print(m);
		
	}
	
	
	
}
