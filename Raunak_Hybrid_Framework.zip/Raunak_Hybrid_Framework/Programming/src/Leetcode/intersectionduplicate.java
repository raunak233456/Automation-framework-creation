package Leetcode;

public class intersectionduplicate {

}
