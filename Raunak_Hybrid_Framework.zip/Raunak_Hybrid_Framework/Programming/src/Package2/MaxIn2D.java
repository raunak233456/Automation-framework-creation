package Package2;

public class MaxIn2D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
