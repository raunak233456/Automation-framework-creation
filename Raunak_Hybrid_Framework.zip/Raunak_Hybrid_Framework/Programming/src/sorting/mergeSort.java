package sorting;

import java.util.Arrays;

public class mergeSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a = {1,6,7,4,3,2};
		a = mergesort1(a);
		System.out.println(Arrays.toString(a));

	}
	
	static int[] mergesort1(int[] a)
	{
		
		if(a.length == 1)
			return a;
		int mid = a.length/2;
		
		
		int[] left = mergesort1(Arrays.copyOfRange(a,0,mid));
		int[] right = mergesort1(Arrays.copyOfRange(a, mid, a.length));
		
		return merge(left,right);
		
	}
	static int[] merge(int[] first, int[] second)
	{
		
		int[] mix = new int[first.length+second.length];
		int i =0;
		int j=0;
		int k=0;
		
	while(i< first.length && j< second.length)
	{
		if(first[i] < second[j])
		{
			mix[k] = first[i];
					i++;
		}
		else
		{
			mix[k] = second[j];	
			}
		
		k++;
	}
	
	while(i<first.length)
	{
		mix[k]= first[i];
		i++;
		k++;
	}
	
	while(j<second.length)
	{
		mix[k] = second[j];
		j++;
		k++;
	}
		
	return mix;
	}
}
		
		
		
		
		
	
