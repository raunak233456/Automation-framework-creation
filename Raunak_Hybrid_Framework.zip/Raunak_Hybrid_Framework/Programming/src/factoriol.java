
public class factoriol {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  // 5 = 5*4*3*2*1
		
		
		int num = 5;
		
	}

}
