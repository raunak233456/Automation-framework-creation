package stack_Queue;

public class stackimplementation {

	protected int[] data;
	private static final int DEAFULT_SIZE = 3; // static -same for all custom stack , private - dont want people to change it directly,final - dont want to change by myself
	
	 int ptr = -1;
	public stackimplementation(int size) // when size is given
	{
		this.data = new int[size]; 
	}
		// when nothing is passed
	public stackimplementation()
	{
		this(DEAFULT_SIZE);
	}
	
	public boolean push(int item)
	{
		//if(ptr == data.length)
			//return false;
		if(ISFULL())
		{
			System.out.println("FUll");
			return false;
		}
			
	    data[++ptr] = item;
		return true;
		}
	
	private boolean ISFULL()// private only accessible within declared class
	{
		
		return ptr == data.length-1;
			
		
		
	}
	public int pop()
	{
		
		if(ISEMPTY())
		{
			System.out.println("IS empty");
		}
		int remove = data[ptr];
		ptr--;
		return remove;
	}
	private boolean ISEMPTY()
	{
		return ptr ==-1;
		
	}

}
