package stack_Queue;

public class QueueImplementation {
    protected int[] data;
	private static final int DEFAULT_SIZE = 10;
	int end =0;
	
	public QueueImplementation (int size)
	{
		this.data = new int[size];
	}
	
	public QueueImplementation ()
	{
		this(DEFAULT_SIZE);
	}
	
	private boolean ISFULL()
	{
		return end == data.length;
	}
	private boolean ISEMPTY()
	{
		return end == 0;
	}
	
	public boolean insert(int item)
	{
		if(ISFULL())
		{
			System.out.println("FULL");
		}
		data[end++]= item;
		return true;
	}
	
	public int remove()
	{
		if(ISEMPTY())
		{
			System.out.println("EMPTY");
		}
		
		int remove = data[0];
		for(int i=1;i<end;i++)
		{
			data[i-1] = data[i];
		}
		end--;
		return remove;
	}
	public void display()
	{
		for(int i=0;i<end;i++)
		{
			System.out.println(data[i]);
		}
	}
	
}
