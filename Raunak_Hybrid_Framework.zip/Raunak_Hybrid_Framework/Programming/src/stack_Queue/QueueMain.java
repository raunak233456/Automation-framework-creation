package stack_Queue;

public class QueueMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueImplementation qu =  new QueueImplementation(5);
		qu.insert(0);
		qu.insert(1);
		qu.insert(2);
		
		System.out.println(qu.remove());
		
		//qu.display();
	}

}
