package LinkedList;

import org.w3c.dom.Node;

public class main {
	
	public static void main(String[] args)
	{
		 LL list = new LL();
	 list.InsertAtFirst(1);
	list.InsertAtFirst(2);
	 list.InsertAtFirst(19);
		// list.display();
		 
		 list.InsertAtLast(100);
		// list.InsertMiddle(90,1);
		 list.display();
		 
	//System.out.println(list.DeleteFirst());	
	 //list.display();
	//System.out.println(list.DeleteLast());
	 //list.display();
	//System.out.println(list.Deletemiddle(2));	
	
		
	 //list.display();
		
	list.value(19);
	}

}
