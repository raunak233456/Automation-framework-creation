package StringRecursion;

public class skipstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.out.println(skipraunak("my name is raunak"));
	}

	static String skipraunak(String u)
			{
		if(u.isEmpty())
			return "";
		
		char ch = u.charAt(0);
		if(u.startsWith("raunak"))
			return skipraunak (u.substring(1));
		return ch+skipraunak(u.substring(1));
		
			}
}
